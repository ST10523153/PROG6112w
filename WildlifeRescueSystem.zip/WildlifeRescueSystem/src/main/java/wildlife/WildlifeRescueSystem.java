/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
/*
 * AI Disclosure: ChatGPT was consulted for initial topic brainstorming 
 * and understanding how to structure an abstract class in Java. 
 * All code was written, tested, and debugged by Ongeziwe DlaminiS.
 */
package wildlife;

/**
 *
 * @author donge
 */
import java.util.ArrayList;
import java.util.Scanner;

public class WildlifeRescueSystem {
    // The ArrayList required by the rubric to store rescue cases in memory
    static ArrayList<RescueCase> rescueCases = new ArrayList<>();
    static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        int choice = 0;
        
        // Do while loop keeps the program running until the user selects Exit (6)
        do {
            displayMenu();
            choice = getValidIntegerInput("Select an option: ");
            
            switch (choice) {
                case 1:
                    createRescueCase();
                    break;
                case 2:
                    searchRescueCase();
                    break;
                case 3:
                    updateRescueStatus();
                    break;
                case 4:
                    displayAllCases();
                    break;
                case 5:
                    generateRescueReport();
                    break;
                case 6:
                    System.out.println("Exiting system. Goodbye!");
                    break;
                default:
                    System.out.println("Invalid option. Please enter a number between 1 and 6.");
            }
        } while (choice != 6);
    }

    // Displays the main menu options to the user
    private static void displayMenu() {
        System.out.println("\n========================================");
        System.out.println("   WILDLIFE RESCUE OPERATIONS SYSTEM    ");
        System.out.println("========================================");
        System.out.println("1. Create Rescue Case");
        System.out.println("2. Search Rescue Case");
        System.out.println("3. Update Rescue Status");
        System.out.println("4. Display All Rescue Cases");
        System.out.println("5. Rescue Report");
        System.out.println("6. Exit");
    }

    // =================================================================
    // --- VALIDATION HELPER METHODS ---
    // =================================================================
    
    private static String getNonEmptyString(String prompt) {
        String input = "";
        while (input.trim().isEmpty()) {
            System.out.print(prompt);
            input = scanner.nextLine();
            if (input.trim().isEmpty()) {
                System.out.println("Error: Input cannot be blank. Try again.");
            }
        }
        return input;
    }

    private static int getValidIntegerInput(String prompt) {
        int value = -1;
        while (value == -1) {
            try {
                System.out.print(prompt);
                value = Integer.parseInt(scanner.nextLine());
                if (value <= 0) {
                    System.out.println("Error: Value must be greater than zero.");
                    value = -1; 
                }
            } catch (NumberFormatException e) {
                System.out.println("Error: Invalid input. Please enter a whole number.");
            }
        }
        return value;
    }
    
    private static double getValidDoubleInput(String prompt) {
        double value = -1;
        while (value == -1) {
            try {
                System.out.print(prompt);
                value = Double.parseDouble(scanner.nextLine());
                if (value <= 0) {
                    System.out.println("Error: Value must be greater than zero.");
                    value = -1; 
                }
            } catch (NumberFormatException e) {
                System.out.println("Error: Invalid input. Please enter a valid number.");
            }
        }
        return value;
    }

    private static boolean isIdUnique(String id) {
        for (RescueCase rc : rescueCases) {
            if (rc.getRescueCaseID().equalsIgnoreCase(id)) {
                return false;
            }
        }
        return true;
    }

    // =================================================================
    // --- MENU OPERATIONS ---
    // =================================================================

    private static void createRescueCase() {
        System.out.println("\n--- Create New Rescue Case ---");
        
        String id = "";
        boolean validId = false;
        while (!validId) {
            id = getNonEmptyString("Enter Rescue Case ID: ");
            if (isIdUnique(id)) {
                validId = true;
            } else {
                System.out.println("Error: Rescue Case ID already exists. Please enter a unique ID.");
            }
        }

        String name = getNonEmptyString("Enter Animal Name: ");
        String species = getNonEmptyString("Enter Species: ");
        String location = getNonEmptyString("Enter Rescue Location: ");
        String ranger = getNonEmptyString("Enter Assigned Ranger: ");
        int days = getValidIntegerInput("Enter Number of Rescue Days: ");
        double dailyCost = getValidDoubleInput("Enter Daily Care Cost: R");

        System.out.println("\nSelect Rescue Type:");
        System.out.println("1. Injured Animal");
        System.out.println("2. Orphaned Animal");
        System.out.println("3. Endangered Species");
        int typeChoice = getValidIntegerInput("Choice: ");

        if (typeChoice == 1) {
            String injury = getNonEmptyString("Enter Injury Description: ");
            double vetCost = getValidDoubleInput("Enter Veterinary Treatment Cost: R");
            System.out.print("Is Surgery Required? (Y/N): ");
            boolean surgery = scanner.nextLine().equalsIgnoreCase("Y");
            
            rescueCases.add(new InjuredAnimalRescue(id, name, species, location, ranger, days, dailyCost, "Pending", injury, vetCost, surgery));
            System.out.println("Injured Animal Rescue case created successfully.");
            
        } else if (typeChoice == 2) {
            int age = getValidIntegerInput("Enter Estimated Age (Months): ");
            double feedingCost = getValidDoubleInput("Enter Feeding Cost: R");
            System.out.print("Is Foster Care Required? (Y/N): ");
            boolean foster = scanner.nextLine().equalsIgnoreCase("Y");
            
            rescueCases.add(new OrphanedAnimalRescue(id, name, species, location, ranger, days, dailyCost, "Pending", age, feedingCost, foster));
            System.out.println("Orphaned Animal Rescue case created successfully.");
            
        } else if (typeChoice == 3) {
            String classification = getNonEmptyString("Enter Conservation Classification: ");
            double securityCost = getValidDoubleInput("Enter Security Cost: R");
            System.out.print("Is Specialist Team Required? (Y/N): ");
            boolean specialist = scanner.nextLine().equalsIgnoreCase("Y");
            
            rescueCases.add(new EndangeredSpeciesRescue(id, name, species, location, ranger, days, dailyCost, "Pending", classification, securityCost, specialist));
            System.out.println("Endangered Species Rescue case created successfully.");
            
        } else {
            System.out.println("Invalid type selected. Case not created.");
        }
    }

    private static void searchRescueCase() {
        System.out.println("\n--- Search Rescue Case ---");
        
        if (rescueCases.isEmpty()) {
            System.out.println("No rescue cases recorded yet.");
            return;
        }

        String searchId = getNonEmptyString("Enter Rescue Case ID to search: ");
        boolean found = false;

        for (RescueCase rc : rescueCases) {
            if (rc.getRescueCaseID().equalsIgnoreCase(searchId)) {
                System.out.println("\nCase Found:");
                System.out.println("----------------------------------------");
                System.out.println(rc.generateSummary());
                System.out.println("----------------------------------------");
                found = true;
                break; 
            }
        }

        if (!found) {
            System.out.println("Rescue Case with ID " + searchId + " was not found.");
        }
    }

    private static void updateRescueStatus() {
        System.out.println("\n--- Update Rescue Status ---");
        
        if (rescueCases.isEmpty()) {
            System.out.println("No rescue cases recorded yet.");
            return;
        }

        String searchId = getNonEmptyString("Enter Rescue Case ID to update: ");
        boolean found = false;

        for (RescueCase rc : rescueCases) {
            if (rc.getRescueCaseID().equalsIgnoreCase(searchId)) {
                System.out.println("Current Status: " + rc.getCurrentRescueStatus());
                String newStatus = getNonEmptyString("Enter new status (e.g., In Progress, Under Observation, Completed): ");
                
                rc.updateRescueStatus(newStatus);
                
                System.out.println("Status updated successfully.");
                found = true;
                break; 
            }
        }

        if (!found) {
            System.out.println("Rescue Case with ID " + searchId + " was not found.");
        }
    }

    private static void displayAllCases() {
        System.out.println("\n--- All Rescue Cases ---");
        
        if (rescueCases.isEmpty()) {
            System.out.println("No rescue cases recorded yet.");
            return;
        }

        for (RescueCase rc : rescueCases) {
            System.out.println(rc.generateSummary());
            System.out.println("----------------------------------------");
        }
    }

    private static void generateRescueReport() {
        if (rescueCases.isEmpty()) {
            System.out.println("No rescue cases recorded yet.");
            return;
        }

        System.out.println("\n========================================");
        System.out.println("          WILDLIFE RESCUE REPORT        ");
        System.out.println("========================================");
        
        double totalCost = 0;
        for (RescueCase rc : rescueCases) {
            System.out.println(rc.generateSummary());
            System.out.println("----------------------------------------");
            
            totalCost += rc.calculateTotalRescueCost();
        }
        
        System.out.println("Total Rescue Cases : " + rescueCases.size());
        System.out.printf("Total Rescue Cost  : R%.2f\n", totalCost);
    }
}