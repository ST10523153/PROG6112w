/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package wildlife;

/**
 *
 * @author donge
 */
// This is the parent class for all animals. I made it 'abstract' because you never 
// just have a generic "Rescue Case" - it's always a specific type (Injured, Orphaned, etc.).
// It implements our interface so it promises to have those methods.
public abstract class RescueCase implements IRescueOperations {
    
    // I made these private to follow 'Encapsulation'. It means other classes can't 
    // just reach in and change an animal's ID or cost directly. They have to use my getters/setters.
    private String rescueCaseID;
    private String animalName;
    private String species;
    private String rescueLocation;
    private String assignedRanger;
    private int numberOfRescueDays;
    private double dailyCareCost;
    private String currentRescueStatus;

    // This is the constructor. When a new animal comes in, we pass all the common 
    // details here so we don't have to repeat this code in every single subclass.
    public RescueCase(String rescueCaseID, String animalName, String species, 
                      String rescueLocation, String assignedRanger, 
                      int numberOfRescueDays, double dailyCareCost, String currentRescueStatus) {
        this.rescueCaseID = rescueCaseID;
        this.animalName = animalName;
        this.species = species;
        this.rescueLocation = rescueLocation;
        this.assignedRanger = assignedRanger;
        this.numberOfRescueDays = numberOfRescueDays;
        this.dailyCareCost = dailyCareCost;
        this.currentRescueStatus = currentRescueStatus;
    }

    // These are my "Getters". They let the rest of the program safely read the private data above.
    public String getRescueCaseID() { return rescueCaseID; }
    public String getSpecies() { return species; }
    public String getRescueLocation() { return rescueLocation; }
    public String getAssignedRanger() { return assignedRanger; }
    public int getNumberOfRescueDays() { return numberOfRescueDays; }
    public double getDailyCareCost() { return dailyCareCost; }
    public String getCurrentRescueStatus() { return currentRescueStatus; }

    // These are the methods from the interface. I'm putting the basic logic here 
    // so all the subclasses inherit it automatically.
   
    public void updateRescueStatus(String newStatus) {
        this.currentRescueStatus = newStatus;
    }

   
    public void startRescue() {
        this.currentRescueStatus = "In Progress";
    }

   
    public void completeRescue() {
        this.currentRescueStatus = "Completed";
    }

    // These are 'abstract' methods. I'm basically saying: "Every rescue case MUST calculate 
    // its own cost and priority, but I'm not going to write the math here. The subclasses will do it."
    public abstract double calculateTotalRescueCost();
    public abstract String determineRescuePriority();
    public abstract String getRescueType();

    // This is the method that formats the report. I put it here so I only have to write 
    // the formatting code once, and all the subclasses can use it.
   
    public String generateSummary() {
        return "Case ID      : " + rescueCaseID + "\n" +
               "Type         : " + getRescueType() + "\n" +
               "Species      : " + species + "\n" +
               "Priority     : " + determineRescuePriority() + "\n" +
               "Status       : " + currentRescueStatus + "\n" +
               String.format("Total Cost   : R%.2f", calculateTotalRescueCost());
    }
}