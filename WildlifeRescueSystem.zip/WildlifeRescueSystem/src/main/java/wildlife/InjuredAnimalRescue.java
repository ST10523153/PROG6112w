/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package wildlife;

/**
 *
 * @author donge
 */
public class InjuredAnimalRescue extends RescueCase {
    // Specific fields for this type
    private String injuryDescription;
    private double veterinaryTreatmentCost;
    private boolean surgeryRequired;

    // Constructor
    public InjuredAnimalRescue(String rescueCaseID, String animalName, String species, 
                               String rescueLocation, String assignedRanger, int numberOfRescueDays, 
                               double dailyCareCost, String currentRescueStatus, 
                               String injuryDescription, double veterinaryTreatmentCost, boolean surgeryRequired) {
        
        // Pass common data to the parent class (RescueCase)
        super(rescueCaseID, animalName, species, rescueLocation, assignedRanger, 
              numberOfRescueDays, dailyCareCost, currentRescueStatus);
        
        this.injuryDescription = injuryDescription;
        this.veterinaryTreatmentCost = veterinaryTreatmentCost;
        this.surgeryRequired = surgeryRequired;
    }

    // Override Methods (Polymorphism)
    @Override
    public String getRescueType() {
        return "Injured Animal Rescue";
    }

    @Override
    public double calculateTotalRescueCost() {
        // Base cost + vet cost
        double total = (getNumberOfRescueDays() * getDailyCareCost()) + veterinaryTreatmentCost;
        // Add R5000 if surgery is required
        if (surgeryRequired) {
            total += 5000.00;
        }
        return total;
    }

    @Override
    public String determineRescuePriority() {
        if (surgeryRequired) {
            return "Critical";
        } else {
            return "High";
        }
    }

    @Override
    public String generateSummary() {
        return "Case ID      : " + getRescueCaseID() + "\n" +
               "Type         : " + getRescueType() + "\n" +
               "Species      : " + getSpecies() + "\n" +
               "Priority     : " + determineRescuePriority() + "\n" +
               "Status       : " + getCurrentRescueStatus() + "\n" +
               String.format("Total Cost   : R%.2f", calculateTotalRescueCost());
    }
}