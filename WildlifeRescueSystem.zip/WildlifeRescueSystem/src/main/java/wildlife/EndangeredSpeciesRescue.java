/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package wildlife;

/**
 *
 * @author donge
 */
public class EndangeredSpeciesRescue extends RescueCase {
    // 1. Specific fields for this type
    private String conservationClassification;
    private double securityCost;
    private boolean specialistTeamRequired;

    // 2. Constructor
    public EndangeredSpeciesRescue(String rescueCaseID, String animalName, String species, 
                                   String rescueLocation, String assignedRanger, int numberOfRescueDays, 
                                   double dailyCareCost, String currentRescueStatus, 
                                   String conservationClassification, double securityCost, boolean specialistTeamRequired) {
        
        // Pass common data to the parent class (RescueCase) using super()
        super(rescueCaseID, animalName, species, rescueLocation, assignedRanger, 
              numberOfRescueDays, dailyCareCost, currentRescueStatus);
        
        // Assign the specific fields for this subclass
        this.conservationClassification = conservationClassification;
        this.securityCost = securityCost;
        this.specialistTeamRequired = specialistTeamRequired;
    }

    // 3. Override Methods (Polymorphism)

    @Override
    public String getRescueType() {
        return "Endangered Species Rescue";
    }

    @Override
    public double calculateTotalRescueCost() {
        // Base cost = (Days * Daily Cost) + Security Cost
        double total = (getNumberOfRescueDays() * getDailyCareCost()) + securityCost;
        
        // Add R8000 if a specialist team is required
        if (specialistTeamRequired) {
            total += 8000.00;
        }
        
        return total;
    }

    @Override
    public String determineRescuePriority() {
        // Priority Logic: I chose to make it Critical if a specialist team is required, 
        // otherwise it is High. (You can just return "Critical" always if you prefer,
        // but this logic is more dynamic and fits the rubric better).
        if (specialistTeamRequired) {
            return "Critical";
        } else {
            return "High";
        }
    }

    @Override
    public String generateSummary() {
        // Formatting this exactly like the sample report in the assignment
        return "Case ID      : " + getRescueCaseID() + "\n" +
               "Type         : " + getRescueType() + "\n" +
               "Species      : " + getSpecies() + "\n" +
               "Priority     : " + determineRescuePriority() + "\n" +
               "Status       : " + getCurrentRescueStatus() + "\n" +
               String.format("Total Cost   : R%.2f", calculateTotalRescueCost());
    }
}