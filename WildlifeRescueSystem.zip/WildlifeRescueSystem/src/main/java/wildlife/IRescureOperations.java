/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package wildlife;

/**
 *
 * @author donge
 */
public interface IRescureOperations {
 // these are the mathods all rescue cases must have
    void updateRescueStatus(String newStatus);
    void startRescure();
    void completeRescue();
    String generateSummary();
}