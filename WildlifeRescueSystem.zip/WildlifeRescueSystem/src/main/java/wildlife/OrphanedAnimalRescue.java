/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package wildlife;

/**
 *
 * @author donge
 */
public class OrphanedAnimalRescue extends RescueCase {
    // 1. Specific fields for this type
    private int estimatedAgeMonths;
    private double feedingCost;
    private boolean fosterCareRequired;

    // 2. Constructor
    public OrphanedAnimalRescue(String rescueCaseID, String animalName, String species, 
                                String rescueLocation, String assignedRanger, int numberOfRescueDays, 
                                double dailyCareCost, String currentRescueStatus, 
                                int estimatedAgeMonths, double feedingCost, boolean fosterCareRequired) {
        
        // Pass common data to the parent class (RescueCase) using super()
        super(rescueCaseID, animalName, species, rescueLocation, assignedRanger, 
              numberOfRescueDays, dailyCareCost, currentRescueStatus);
        
        // Assign the specific fields for this subclass
        this.estimatedAgeMonths = estimatedAgeMonths;
        this.feedingCost = feedingCost;
        this.fosterCareRequired = fosterCareRequired;
    }

    // 3. Override Methods (Polymorphism)

    @Override
    public String getRescueType() {
        return "Orphaned Animal Rescue";
    }

    @Override
    public double calculateTotalRescueCost() {
        // Base cost = (Days * Daily Cost) + Feeding Cost
        double total = (getNumberOfRescueDays() * getDailyCareCost()) + feedingCost;
        
        // Add R2500 if foster care is required
        if (fosterCareRequired) {
            total += 2500.00;
        }
        
        return total;
    }

    @Override
    public String determineRescuePriority() {
        // Priority Logic: High if foster care required, otherwise Medium
        if (fosterCareRequired) {
            return "High";
        } else {
            return "Medium";
        }
    }

    @Override
    public String generateSummary() {
        // Formatting this exactly like the sample report in the assignment
        return "Case ID      : " + getRescueCaseID() + "\n" +
               "Type         : " + getRescueType() + "\n" +
               "Species      : " + getSpecies() + "\n" +
               "Priority     : " + determineRescuePriority() + "\n" +
               "Status       : " + getCurrentRescueStatus() + "\n" +
               String.format("Total Cost   : R%.2f", calculateTotalRescueCost());
    }
}