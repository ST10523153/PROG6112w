/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package wildlife;

import org.junit.Test;
import static org.junit.Assert.*;

// This is my JUnit test class. I wrote this to prove that my math and logic 
// actually work before I submit the assignment.
public class RescueCaseTest {

    // ==========================================
    // TEST 1: Does the Injured Animal math work?
    // ==========================================
    @Test
    public void testInjuredAnimalCostCalculation() {
        // ARRANGE: I'm setting up a fake test case. 
        // 5 days at R1000/day + R5000 vet bill + R5000 surgery fee = should be R15000
        InjuredAnimalRescue injured = new InjuredAnimalRescue(
                "WR01", "Elephant", "African", "Kruger", "John", 
                5, 1000.0, "Pending", "Broken Leg", 5000.0, true);
        
        // ACT: I'm calling the method I want to test.
        double expectedCost = 15000.0;
        double actualCost = injured.calculateTotalRescueCost();
        
        // ASSERT: Now I check if the actual cost matches what I expected. 
        // The "0.01" is a small margin of error so Java doesn't get fussy about tiny decimal differences.
        assertEquals("Injured Animal cost calculation is incorrect.", expectedCost, actualCost, 0.01);
    }

    // ==========================================
    // TEST 2: Does the Orphaned Animal math work?
    // ==========================================
    @Test
    public void testOrphanedAnimalCostCalculation() {
        // ARRANGE: 10 days at R500/day + R1000 feeding + R2500 foster care = R8500
        OrphanedAnimalRescue orphaned = new OrphanedAnimalRescue(
                "WR02", "Rhino", "White", "Reserve", "Sarah", 
                10, 500.0, "Pending", 6, 1000.0, true);
        
        // ACT
        double expectedCost = 8500.0;
        double actualCost = orphaned.calculateTotalRescueCost();
        
        // ASSERT
        assertEquals("Orphaned Animal cost calculation is incorrect.", expectedCost, actualCost, 0.01);
    }

    // ==========================================
    // TEST 3: Does the Endangered Species math work?
    // ==========================================
    @Test
    public void testEndangeredSpeciesCostCalculation() {
        // ARRANGE: 3 days at R2000/day + R5000 security + R8000 specialist = R19000
        EndangeredSpeciesRescue endangered = new EndangeredSpeciesRescue(
                "WR03", "Pangolin", "Ground", "Park", "Mike", 
                3, 2000.0, "Pending", "Critically Endangered", 5000.0, true);
        
        // ACT
        double expectedCost = 19000.0;
        double actualCost = endangered.calculateTotalRescueCost();
        
        // ASSERT
        assertEquals("Endangered Species cost calculation is incorrect.", expectedCost, actualCost, 0.01);
    }

    // ==========================================
    // TEST 4: Is the Priority logic working?
    // ==========================================
    @Test
    public void testRescuePriorityLogic() {
        // ARRANGE: I'm making two animals. One needs surgery, one doesn't.
        InjuredAnimalRescue criticalAnimal = new InjuredAnimalRescue(
                "WR04", "Lion", "African", "Reserve", "Mike", 
                2, 400.0, "Pending", "Broken Bone", 1000.0, true); // surgery = true
                
        InjuredAnimalRescue highPriorityAnimal = new InjuredAnimalRescue(
                "WR05", "Lion", "African", "Reserve", "Mike", 
                2, 400.0, "Pending", "Small Cut", 1000.0, false); // surgery = false
        
        // ACT & ASSERT: The one with surgery should be "Critical", the other should be "High".
        assertEquals("Priority should be Critical because surgery is required.", "Critical", criticalAnimal.determineRescuePriority());
        assertEquals("Priority should be High because surgery is not required.", "High", highPriorityAnimal.determineRescuePriority());
    }

    // ==========================================
    // TEST 5: Does updating the status actually save?
    // ==========================================
    @Test
    public void testStatusUpdate() {
        // ARRANGE
        InjuredAnimalRescue injured = new InjuredAnimalRescue(
                "WR06", "Zebra", "Plains", "Farm", "Anna", 
                1, 100.0, "Pending", "Dehydrated", 500.0, false);
        
        // ACT: I'm changing the status to something new.
        injured.updateRescueStatus("In Progress");
        
        // ASSERT: Did it actually change? It should not say "Pending" anymore.
        assertEquals("Status was not updated correctly.", "In Progress", injured.getCurrentRescueStatus());
    }
}