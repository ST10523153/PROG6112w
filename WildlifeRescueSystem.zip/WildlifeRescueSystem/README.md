# Wildlife Rescue Operations System

Module:** Programming 1B (PROG6112w)  
Assignment:** Practical Assignment 2  
Author:** Ongeziwe Dlamini, ST10523153  


1. Project Overview
This is a Java console-based application built to assist "Wildlife SA", a non-profit conservation organisation. The system replaces manual paper-based tracking by allowing staff to record, manage, search, and report on wildlife rescue cases. 

The application handles three distinct types of rescues (Injured, Orphaned, and Endangered Species), calculates their specific total rescue costs, determines their rescue priority, and outputs formatted operational reports.

2. Architecture & Technical Design
I used core Object-Oriented Programming (OOP) principles to ensure the system is scalable and easy to maintain. Here is how the code is structured:

*   **`IRescueOperations` (Interface):** Defines the contract for rescue operations. Any class that is a "Rescue Case" must implement these methods (`updateRescueStatus`, `startRescue`, `completeRescue`, `generateSummary`).
*   **`RescueCase` (Abstract Base Class):** This class provides **abstraction** and **encapsulation**. It stores all common attributes (Rescue Case ID, Animal Name, Species, Location, Ranger, Days, Daily Cost, Status) as `private` variables. It also contains the abstract methods `calculateTotalRescueCost()`, `determineRescuePriority()`, and `getRescueType()`, forcing the subclasses to provide their own specific logic.
*   **The Subclasses (`InjuredAnimalRescue`, `OrphanedAnimalRescue`, `EndangeredSpeciesRescue`):** These classes demonstrate **inheritance** (`extends RescueCase`) and **method overriding** (Polymorphism). Each calculates its total cost and priority differently based on unique business rules.
*   **`WildlifeRescueSystem` (Main Class):** Manages the `ArrayList<RescueCase>` (as required by the brief to store data in memory) and handles the console user interface. It contains robust input validation to ensure the program does not crash on invalid input.

3. Cost & Priority Logic
The logic for the different rescue types is handled as follows:

| Rescue Type | Base Cost Calculation | Additional Surcharge | Priority Logic |
| :--- | :--- | :--- | :--- |
| **Injured Animal** | (Days * Daily Cost) + Vet Cost | **R5,000** if surgery is required. | Critical if surgery required, otherwise High. |
| **Orphaned Animal** | (Days * Daily Cost) + Feeding Cost | **R2,500** if foster care is required. | High if foster care required, otherwise Medium. |
| **Endangered Species**| (Days * Daily Cost) + Security Cost | **R8,000** if a specialist team is required.| Critical if specialist required, otherwise High. |

4. How to Run the Application
1. Open the project in **Apache NetBeans**.
2. Ensure the JUnit library is added to your project library (if not already included by default).
3. Locate the `WildlifeRescueSystem.java` file in the `wildlife` package.
4. Right-click the file and select **Run File** (or press Shift + F6).
5. Use the console menu to navigate (1-6). 
   * *Tip:* Try entering letters where numbers are expected to test the validation loops. The program should not crash.

5. Running Unit Tests
I have written JUnit tests in `RescueCaseTest.java` to verify the core mathematical and logical functionality.
1. In the Projects window, expand **Test Packages -> wildlife**.
2. Right-click `RescueCaseTest.java` and select **Run File**.
3. Verify that all tests pass (green checkmarks).

6. Academic Integrity & AI Disclosure
As per the assignment instructions (PROG6112w, Instruction 3 and 4), I am disclosing the use of AI tools.
- **AI Usage:** ChatGPT was consulted for initial topic brainstorming, understanding the structural requirements of abstract classes in Java, and verifying the syntax for `try-catch` validation loops. 
- **Original Work:** All code was typed, compiled, and debugged by me. The specific logic for cost calculations, the priority decision trees, the exact formatting of the printed report, and the JUnit test assertions were designed and implemented by me based on the assignment brief.

---
### 7. References (Harvard Style)
*   Deitel, P. and Deitel, H. (2018) *Java: How to Program, Early Objects*. 11th edn. Boston: Pearson Education.
*   Oracle (2024) *Java Platform, Standard Edition 8 API Specification*. Available at: https://docs.oracle.com/javase/8/docs/api/ (Accessed: 28 September 2026).
*   Schildt, H. (2018) *Java: The Complete Reference*. 11th edn. New York: McGraw-Hill Education.
*   The Independent Institute of Education (2026) *PROG6112w: Programming 1B Practical Assignment 2*. Johannesburg: IIE.
